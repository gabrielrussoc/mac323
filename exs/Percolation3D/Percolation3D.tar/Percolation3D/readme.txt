Exercicio 2.4.18 - Percolation in three dimensions 
disponivel em http://introcs.cs.princeton.edu/java/24percolation/
Nome: Gabriel de Russo e Carmo
N USP: 9298041
Data: 08/03/2016
OBS: Compilado com 'javac-algs4'

Classe principal PercPlot
